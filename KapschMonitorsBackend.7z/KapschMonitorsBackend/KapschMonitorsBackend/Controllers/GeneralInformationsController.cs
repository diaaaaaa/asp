﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using KapschMonitorsBackend.Data;
using KapschMonitorsBackend.Models;
using Microsoft.AspNetCore.Authorization;

namespace KapschMonitorsBackend.Controllers
{
    [Authorize]
    public class GeneralInformationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public GeneralInformationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: GeneralInformations
        public async Task<IActionResult> Index()
        {
            return View(await _context.GeneralInformation.ToListAsync());
        }

        // GET: GeneralInformations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var generalInformation = await _context.GeneralInformation
                .SingleOrDefaultAsync(m => m.Id == id);
            if (generalInformation == null)
            {
                return NotFound();
            }

            return View(generalInformation);
        }

        // GET: GeneralInformations/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: GeneralInformations/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Text")] GeneralInformation generalInformation)
        {
            if (ModelState.IsValid)
            {
                _context.Add(generalInformation);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(generalInformation);
        }

        // GET: GeneralInformations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var generalInformation = await _context.GeneralInformation.SingleOrDefaultAsync(m => m.Id == id);
            if (generalInformation == null)
            {
                return NotFound();
            }
            return View(generalInformation);
        }

        // POST: GeneralInformations/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Text")] GeneralInformation generalInformation)
        {
            if (id != generalInformation.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(generalInformation);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GeneralInformationExists(generalInformation.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(generalInformation);
        }

        // GET: GeneralInformations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var generalInformation = await _context.GeneralInformation
                .SingleOrDefaultAsync(m => m.Id == id);
            if (generalInformation == null)
            {
                return NotFound();
            }

            return View(generalInformation);
        }

        // POST: GeneralInformations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var generalInformation = await _context.GeneralInformation.SingleOrDefaultAsync(m => m.Id == id);
            _context.GeneralInformation.Remove(generalInformation);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool GeneralInformationExists(int id)
        {
            return _context.GeneralInformation.Any(e => e.Id == id);
        }
    }
}
